$(document).ready(function(){
    $("ul.gnb>li").mouseover(function(){
        $(this).find("ul.sub").stop().slideDown();
    });
    $("ul.gnb>li").mouseout(function(){
        $(this).find("ul.sub").stop().slideUp();
    });

    $(".slide li").eq(0).siblings().hide();

    var sno=0;
    setInterval(function(){
        $(".slide li").eq(sno).fadeOut(1500);
        sno++;
        if(sno>2) sno=0;
        $(".slide li").eq(sno).fadeIn(1500);
    }, 3000);

    $(".notice_gal h3").click(function(){
        $(".notice_gal h3, .notice_gal ul").removeClass("on");
        $(this).addClass("on");
        $(this).next("ul").addClass("on");
    });
});