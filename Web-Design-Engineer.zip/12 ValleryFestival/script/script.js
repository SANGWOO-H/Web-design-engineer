$(document).ready(function(){

    //메뉴
    $("ul.gnb>li").mouseover(function(){
        $(this).find("ul.sub").stop().slideDown();
    });
    $("ul.gnb>li").mouseout(function(){
        $(this).find("ul.sub").stop().slideUp();
    });

    //슬라이드
    var sno=0;
    setInterval(function(){
        $(".slide li").eq(sno).animate({"left":"800px"}, 1000);
        sno++;
        if(sno>2) sno=0;
        $(".slide li").eq(sno).css({"left":"-800px"});
        $(".slide li").eq(sno).animate({"left":"0"}, 1000);
    }, 3000);

    //팝업
    $(".notice li").eq(0).click(function(){
        $(".modal").show();
    });
    $("input").eq(0).click(function(){
        $(".modal").hide();
    });
});