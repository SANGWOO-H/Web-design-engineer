$(document).ready(function(){
    $("ul.gnb>li").mouseover(function(){
        $("ul.sub, .bg").stop().slideDown();
    });
    $("ul.gnb>li").mouseout(function(){
        $("ul.sub, .bg").stop().slideUp();
    });

    var slide=$(".slide li");
    var sno=0;
    var lastno=slide.length-1;
    function playSlide(){
        $(slide[sno]).animate({
        "left":"1200px"
        },2000,function(){
        $(this).css({"left":"-1200px"});
        });
        sno++;
        if(sno>lastno) sno=0;
        $(slide[sno]).animate({ 
        "left":"0"
        },2000);		
        }
    setInterval(function(){
    playSlide();
    },3000);

    $(".notice li").eq(0).click(function(){
        $(".modal").show();
    });
    $("input").eq(0).click(function(){
        $(".modal").hide();
    });
});