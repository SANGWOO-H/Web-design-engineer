$(document).ready(function(){
    
    //메뉴
    $("ul.gnb>li").mouseover(function(){
        $(this).find("ul.sub").stop().slideDown();
    });
    $("ul.gnb>li").mouseout(function(){
        $(this).find("ul.sub").stop().slideUp();
    });

    //슬라이드
    $(".slide li").eq(0).siblings().hide();

    var slideNo=0;
    setInterval(function(){
        if(slideNo<2){
            slideNo++
        }else{
            slideNo=0;
        }
        $(".slide li").eq(slideNo).siblings().fadeOut(1000);
        $(".slide li").eq(slideNo).fadeIn(1000);
    },3000);
    
    //공지사항,갤러리
    $(".notice_gal h3").click(function(){
        $(".notice_gal h3, .notice_gal ul").removeClass("on");
        $(this).addClass("on");
        $(this).next("ul").addClass("on");
    });

    //팝업
    $("ul.notice>li").eq(0).click(function(){
        $(".modal").show();
    });
    $("input").click(function(){
        $(".modal").hide();
    });
});